import * as React from 'react';
import { Avatar, Button, Dialog, DialogTitle, List, ListItem, ListItemAvatar, ListItemButton, ListItemText } from '@mui/material';
import { blue } from '@mui/material/colors';

const style = {
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

export interface SimpleDialogProps {
    open: boolean;
    onClose: (value: string[]) => void;
}

const emails = ['username@gmail.com', 'user02@gmail.com'];

export default function BasicDialog(props: SimpleDialogProps) {
    const { onClose, open } = props;
    const [selectedEmails, setSelectedEmails] = React.useState<string[]>([])

    const handleClose = () => {
        onClose(selectedEmails);
    };

    const handleListItemClick = (value: string) => {
        setSelectedEmails([...selectedEmails, value])
    };

    return (
        <Dialog open={open}>
            <DialogTitle>Set backup account</DialogTitle>
            <List sx={{ pt: 0 }}>
                {emails.map((email) => (
                    <ListItem disableGutters key={email}>
                        <ListItemButton onClick={() => handleListItemClick(email)}>
                            <ListItemAvatar>
                                <Avatar sx={{ bgcolor: blue[100], color: blue[600] }}>
                                    foo1
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={email} />
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
            <Button onClick={handleClose}>Ok</Button>
        </Dialog>
    );
}