import * as React from 'react';
import Button from '@mui/material/Button';
import Modal from '@mui/material/Modal';
import { Avatar, Box, DialogTitle, List, ListItem, ListItemAvatar, ListItemButton, ListItemText } from '@mui/material';
import { blue } from '@mui/material/colors';

// const emails = ['username@gmail.com', 'user02@gmail.com'];

export interface SimpleDialogProps {
    onClose: (value: string[]) => void;
    emails: string[]
}

const style = {
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

export default function BasicModal(props: Readonly<SimpleDialogProps>) {
    const [open, setOpen] = React.useState(false);
    const [selectedEmails, setSelectedEmails] = React.useState<string[]>([])

    const handleOpen = () => setOpen(true)

    const handleListItemClick = (value: string) => {
        setSelectedEmails([...selectedEmails, value])
    };

    function handleClose() {
        setOpen(false);
        props.onClose(selectedEmails)
        setSelectedEmails([])
    }

    return (
        <div>
            <Button onClick={handleOpen}>Open modal</Button>
            <Modal
                open={open}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <DialogTitle>Set backup account</DialogTitle>
                    <List sx={{ pt: 0 }}>
                        {props.emails.map((email) => (
                            <ListItem disableGutters key={email}>
                                <ListItemButton onClick={() => handleListItemClick(email)}>
                                    <ListItemAvatar>
                                        <Avatar sx={{ bgcolor: blue[100], color: blue[600] }}>
                                            foo1
                                        </Avatar>
                                    </ListItemAvatar>
                                    <ListItemText primary={email} />
                                </ListItemButton>
                            </ListItem>
                        ))}
                    </List>
                    <Button onClick={handleClose}>Ok</Button>
                </Box>
            </Modal>
        </div>
    );
}